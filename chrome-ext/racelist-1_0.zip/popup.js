async function fetchRaces() {
    try {
        const response = await fetch("https://racelist.gr/min.races.json");
        const races = await response.json();

        // Get today's date
        const today = new Date().toISOString().split("T")[0];

        // Filter upcoming races
        const upcomingRaces = races.filter(race => race.Date >= today);

        // Sort races by date
        upcomingRaces.sort((a, b) => new Date(a.Date) - new Date(b.Date));

        // Display races
        const raceList = document.getElementById("raceList");
        raceList.innerHTML = "";

        if (upcomingRaces.length === 0) {
            raceList.innerHTML = "<p>No upcoming races found.</p>";
            return;
        }

        upcomingRaces.forEach(race => {
            const raceElement = document.createElement("div");
            raceElement.classList.add("race");

            raceElement.innerHTML = `
                <div class="race-title">${race.Title}</div>
                <div class="race-date">${race.Date} - ${race.Location}</div>
            `;

            if (race.SignupLink) {
              raceElement.innerHTML += `
                <a class="race-link" href="${race.SignupLink}" target="_blank">Sign Up</a>
              `
            }

            raceList.appendChild(raceElement);
        });
    } catch (error) {
        document.getElementById("raceList").innerHTML = "<p>Error fetching races.</p>";
        console.error("Error fetching race data:", error);
    }
}

// Run fetchRaces when popup opens
fetchRaces();

